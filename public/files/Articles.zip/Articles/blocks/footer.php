<footer class="footer">
  <div class="container">
    <div class="left-footer">
      <span class="text-muted">AlexProger &copy 2021</span>
    </div>
    <div class="right-footer">
      <span class="text-muted">Слава Україні!</span>
    </div>
  </div>
</footer>
